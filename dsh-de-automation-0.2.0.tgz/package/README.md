# dsh-de-automation

de-automation：把对话里那股「机器生成」的味道压下去。

零运行时依赖。不 import 任何 `@deepseek-ai/*` 包，靠宿主注入的 `systemPrompt` 和 `tools` 两个服务干活。所以 tgz、本地目录、GitHub 仓库三种装法都能用，装完不用额外配 node_modules。

## 装法

在 DSHA 的「添加插件 → 输入包名、仓库地址或本地目录」里，三种填法任选：

| 填法 | 值 |
| --- | --- |
| 本地目录 | `/root/dsh-de-automation` |
| 本地 tgz | `/root/dsh-de-automation-0.2.0.tgz` |
| GitHub | `https://github.com/<你的用户名>/dsh-de-automation`（推上去之后） |

装完确认 `~/.dsh/profiles/<profile>/package.json` 里 `dsh.profile.bundles` 出现了 `dsh-de-automation`——插件管理器会自动补，但值得看一眼。然后重启 dsh，或等 HMR 重载配置层。

## 它做什么

**一、系统提示守则。** 每轮请求都带上一段文风约束，不需要每次喊「自然点」。三档强度：

| 档位 | 内容 |
| --- | --- |
| `light` | 只砍最扎眼的：套话开场、总结收尾、复述提问、三段式、客服腔、emoji |
| `standard`（默认） | 再加填充词、加粗小标题、态度与句子节奏 |
| `strong` | 再加：不罗列所有分支、不替人规划下一步、长度不注水、允许口语 |

**二、`deai_lint` 工具。** 喂一段文字，按规则表数出机器腔，给出评分、命中位置和改法。

- `text`：要查的文本
- `strict`：严格模式，轻的也扣分

评分 100 减权重扣分，四档：干净 / 带点味 / 明显AI腔 / 重灾区。
规则表在 `lib/index.js` 的 `RULES` 里，纯数据，加词删词不用碰逻辑。

## 配置

patch 层里覆盖 `config`：

```yaml
- id: de-automation
  name: 'dsh-de-automation'
  config:
    enabled: true
    strength: standard   # light | standard | strong
    lint: true           # 是否注册 deai_lint
    sectionOrder: 60     # 越小越靠前；persona 在 0，工具说明在 1000+
    bans: []             # 额外禁用词，拼到守则末尾
```

`bans` 放私人雷区：

```yaml
    bans: ['丑话说前头', '希望对你有帮助', '作为一个 AI']
```

## 已知边界

这层是提示词约束，不是后处理过滤器。模型偶尔照样会写出「总之」，
真兜底还是靠眼睛，加上 `deai_lint` 这把尺子。

规则清单与迭代记录在 `DeAutomation-Ledger.md`，那份比本文件重要。
